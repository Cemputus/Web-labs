npm install first

then npm run